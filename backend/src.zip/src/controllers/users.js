const User = require('../models/User');
const { executeIgdbQuery } = require('../services/igdb');

// Helpers
const isValidNumericId = (value) => {
  const numericValue = Number(value);
  return Number.isInteger(numericValue) && numericValue > 0;
};

const buildIgdbImgUrl = (imagePath) => {
  if (!imagePath) {
    return null;
  }

  if (imagePath.startsWith('//')) {
    return `https:${imagePath}`;
  }

  return imagePath;
};

const mapGameMiniCard = (igdbGame) => {
  let coverUrl = null;
  if (igdbGame.cover && igdbGame.cover.url) {
    coverUrl = buildIgdbImgUrl(igdbGame.cover.url);
  }

  return {
    id: igdbGame.id,
    name: igdbGame.name || null,
    coverUrl
  };
};

// GET /me
const getMe = async (req, res) => {
  try {
    const payload = req.payload;

    const user = await User.findById(payload.userId).select('-password'); // Everything but password '-password'
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json(user);
  } catch (error) {
    return res.status(500).json({ message: 'Error obtaining user info' });
  }
};

// PATCH /me (optional)
const updateMe = async (req, res) => {
  try {
    const payload = req.payload;
    const { avatarUrl, bio } = req.body;

    const updateData = {};

    if (avatarUrl !== undefined) {
      updateData.avatarUrl = avatarUrl;
    }

    if (bio !== undefined) {
      updateData.bio = bio;
    }

    const updateKeys = Object.keys(updateData);
    if (updateKeys.length === 0) {
      return res.status(400).json({ message: 'Missing fields to update' });
    }

    const updatedUser = await User.findByIdAndUpdate(
      payload.userId,
      updateData,
      { new: true }
    ).select('-password');

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json(updatedUser);
  } catch (error) {
    return res.status(500).json({ message: 'Error updating profile' });
  }
};

// GET /:id (admin optional)
const getUserById = async (req, res) => {
  try {
    const userId = req.params.id;

    if (!userId) {
      return res.status(400).json({ message: 'Missing parameter user ID' });
    }

    const user = await User.findById(userId).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json(user);
  } catch (error) {
    return res.status(500).json({ message: 'Error obtaining user by ID' });
  }
};

// GET / (admin optional list users)
const getUsersList = async (req, res) => {
  try {
    const users = await User.find().select('-password');
    return res.status(200).json(users);
  } catch (error) {
    return res.status(500).json({ message: 'Error obtaining users list' });
  }
};

// Favorites & Wishlist (mini cards)

// GET /me/favorites
const getMyFavorites = async (req, res) => {
  try {
    const payload = req.payload;

    const user = await User.findById(payload.userId).select('favorites');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    let favoritesIds = [];
  if (Array.isArray(user.favorites)) {
    favoritesIds = user.favorites;
  }
    if (favoritesIds.length === 0) {
      return res.status(200).json([]);
    }

    const idsString = favoritesIds.join(', ');
    const igdbQuery = `
      fields name, cover.url;
      where id = (${idsString});
      limit 100;
    `;

    const igdbGames = await executeIgdbQuery('games', igdbQuery);

    const miniCards = [];
    if (igdbGames && Array.isArray(igdbGames)) {
      igdbGames.forEach((igdbGame) => {
        miniCards.push(mapGameMiniCard(igdbGame));
      });
    }

    return res.status(200).json(miniCards);
  } catch (error) {
    return res.status(500).json({ message: 'Error obtaining favorites' });
  }
};

// POST /me/favorites/:gameId
const addFavorite = async (req, res) => {
  try {
    const payload = req.payload;
    const gameId = req.params.gameId;

    if (!gameId) {
      return res.status(400).json({ message: 'Missing parameter game ID' });
    }

    if (!isValidNumericId(gameId)) {
      return res.status(400).json({ message: 'Invalid game ID' });
    }

    const numericGameId = Number(gameId);

    const updatedUser = await User.findByIdAndUpdate(
      payload.userId,
      { $addToSet: { favorites: numericGameId } },
      { new: true }
    ).select('_id');

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json({ message: 'Game added to favorites' });
  } catch (error) {
    return res.status(500).json({ message: 'Error adding favorite' });
  }
};

// DELETE /me/favorites/:gameId
const removeFavorite = async (req, res) => {
  try {
    const payload = req.payload;
    const gameId = req.params.gameId;

    if (!gameId) {
      return res.status(400).json({ message: 'Missing parameter game ID' });
    }

    if (!isValidNumericId(gameId)) {
      return res.status(400).json({ message: 'Invalid game ID' });
    }

    const numericGameId = Number(gameId);

    const updatedUser = await User.findByIdAndUpdate(
      payload.userId,
      { $pull: { favorites: numericGameId } },
      { new: true }
    ).select('_id');

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json({ message: 'Game removed from favorites' });
  } catch (error) {
    return res.status(500).json({ message: 'Error removing favorite' });
  }
};

// GET /me/wishlist
const getMyWishlist = async (req, res) => {
  try {
    const payload = req.payload;

    const user = await User.findById(payload.userId).select('wishlist');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    let wishlistIds = [];
  if (Array.isArray(user.wishlist)) {
    wishlistIds = user.wishlist;
  }
    if (wishlistIds.length === 0) {
      return res.status(200).json([]);
    }

    const idsString = wishlistIds.join(', ');
    const igdbQuery = `
      fields name, cover.url;
      where id = (${idsString});
      limit 100;
    `;

    const igdbGames = await executeIgdbQuery('games', igdbQuery);

    const miniCards = [];
    if (igdbGames && Array.isArray(igdbGames)) {
      igdbGames.forEach((igdbGame) => {
        miniCards.push(mapGameMiniCard(igdbGame));
      });
    }

    return res.status(200).json(miniCards);
  } catch (error) {
    return res.status(500).json({ message: 'Error obtaining wishlist' });
  }
};

// POST /me/wishlist/:gameId
const addWishlist = async (req, res) => {
  try {
    const payload = req.payload;
    const gameId = req.params.gameId;

    if (!gameId) {
      return res.status(400).json({ message: 'Missing parameter game ID' });
    }

    if (!isValidNumericId(gameId)) {
      return res.status(400).json({ message: 'Invalid game ID' });
    }

    const numericGameId = Number(gameId);

    const updatedUser = await User.findByIdAndUpdate(
      payload.userId,
      { $addToSet: { wishlist: numericGameId } },
      { new: true }
    ).select('_id');

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json({ message: 'Game added to wishlist' });
  } catch (error) {
    return res.status(500).json({ message: 'Error adding wishlist' });
  }
};

// DELETE /me/wishlist/:gameId
const removeWishlist = async (req, res) => {
  try {
    const payload = req.payload;
    const gameId = req.params.gameId;

    if (!gameId) {
      return res.status(400).json({ message: 'Missing parameter game ID' });
    }

    if (!isValidNumericId(gameId)) {
      return res.status(400).json({ message: 'Invalid game ID' });
    }

    const numericGameId = Number(gameId);

    const updatedUser = await User.findByIdAndUpdate(
      payload.userId,
      { $pull: { wishlist: numericGameId } },
      { new: true }
    ).select('_id');

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json({ message: 'Game removed from wishlist' });
  } catch (error) {
    return res.status(500).json({ message: 'Error removing wishlist' });
  }
};

module.exports = {
  getMe,
  updateMe,
  getUserById,
  getUsersList,
  getMyFavorites,
  addFavorite,
  removeFavorite,
  getMyWishlist,
  addWishlist,
  removeWishlist
};
