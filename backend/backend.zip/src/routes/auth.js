const express = require('express');
const router = express.Router();

const { register, login, refresh } = require('../controllers/auth');

// POST /register
router.post('/register', register);

// POST /login
router.post('/login', login);

// POST /refresh
router.post('/refresh', refresh);

module.exports = router;

// Protegido (opcional):

// POST /logout (si quieres cerrar sesión “cliente-side” basta; si lo haces server-side, puedes protegerlo con access token)