// routes/users.js → base /api/users

// Protegidos con access token (middleware authToken.js):

// GET /me → devuelve info del usuario logueado

// PATCH /me (opcional) → editar perfil

// Solo admin (authToken + roleCheck):

// GET /:id (opcional)

// GET / (opcional list users)

const {
  getMe,
  updateMe,
  getUserById,
  getUsersList
} = require('../controllers/users');

// Protected (access token)
router.get('/me', verifyToken, getMe);
router.patch('/me', verifyToken, updateMe);

// Admin only
router.get('/:id', verifyToken, roleCheck, getUserById);
router.get('/', verifyToken, roleCheck, getUsersList);

module.exports = router;