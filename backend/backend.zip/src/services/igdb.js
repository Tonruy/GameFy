

// Token from Amazon/Twitch :
const getTwitchAccessToken = async () => {
  try {
    const response = await fetch(
      `https://id.twitch.tv/oauth2/token?client_id=${process.env.TWITCH_CLIENT_ID}&client_secret=${process.env.TWITCH_CLIENT_SECRET}&grant_type=client_credentials`,
      {
        method: 'POST'
      }
    );

    const tokenData = await response.json();

    if (!response.ok) {
      console.error('Error obtaining Twitch token:', tokenData);
      return null;
    }

    return tokenData.access_token;

  } catch (error) {
    console.error('Error making the connection with Twitch', error.message);
    return null;
  }
};

const executeIgdbQuery = async (endpoint, queryBody) => {
  try {
    const accessToken = await getTwitchAccessToken();
    
    if (!accessToken) {
      console.error('Could not get access token');
      return [];
    }
    
    // Dinamic endpoint depending on what is searching (genres, platform...)
    const response = await fetch(`${process.env.IGDB_BASE_URL}/${endpoint}`, {
      method: 'POST',
      headers: {
        'Client-ID': process.env.TWITCH_CLIENT_ID,
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'text/plain'
      },
      body: queryBody
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Error consulting IGDB:', data);
      return [];
    }

    return data;

  } catch (error) {
    console.error('Error executing query on IGDB:', error.message);
    return [];
  }
};

module.exports = {
  getTwitchAccessToken,
  executeIgdbQuery
};

