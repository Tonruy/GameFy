const User = require('../models/User');

// GET /me
const getMe = async (req, res) => {
  try {
    const payload = req.payload;

    const user = await User.findById(payload.userId).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json(user);
  } catch (error) {
    return res.status(500).json({ message: 'Error obtaining user info' });
  }
};

// PATCH /me (optional)
const updateMe = async (req, res) => {
  try {
    const payload = req.payload;
    const { username, avatarUrl, bio } = req.body;

    const updatedUser = await User.findByIdAndUpdate(
      payload.userId,
      {
        ...(username !== undefined ? { username } : {}),
        ...(avatarUrl !== undefined ? { avatarUrl } : {}),
        ...(bio !== undefined ? { bio } : {})
      },
      { new: true }
    ).select('-password');

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json(updatedUser);
  } catch (error) {
    return res.status(500).json({ message: 'Error updating profile' });
  }
};

// GET /:id (admin optional)
const getUserById = async (req, res) => {
  try {
    const userId = req.params.id;

    if (!userId) {
      return res.status(400).json({ message: 'Missing parameter user ID' });
    }

    const user = await User.findById(userId).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json(user);
  } catch (error) {
    return res.status(500).json({ message: 'Error obtaining user by ID' });
  }
};

// GET / (admin optional list users)
const getUsersList = async (req, res) => {
  try {
    const users = await User.find().select('-password');
    return res.status(200).json(users);
  } catch (error) {
    return res.status(500).json({ message: 'Error obtaining users list' });
  }
};

module.exports = {
  getMe,
  updateMe,
  getUserById,
  getUsersList
};